package com.example.test.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.test.model.Topic;
import com.example.test.serviceImpl.TopicServiceImpl;

@RestController
public class TopicController {

	@Autowired TopicServiceImpl topicServiceImpl;
	//Get method
	//URI- /hello
	@RequestMapping(method = RequestMethod.GET,path = "/topics")
	public List<Topic> getAllTopics() {
		return topicServiceImpl.getAllTopics();
	}
	
	@RequestMapping(method = RequestMethod.GET,path = "/topic/{id}")
	public Optional<Topic> getTopicByName(@PathVariable int id) {
		return topicServiceImpl.getTopicById(id);
	}
	
	@RequestMapping(method = RequestMethod.POST,path = "/topics")
	public void addTopic(@RequestBody Topic topic) {
		 topicServiceImpl.addTopic(topic);
	}
	
	@RequestMapping(method = RequestMethod.PUT,path ="/topic/{id}")
	public void updateTopic(@RequestBody Topic topic, @PathVariable int id) {
		 topicServiceImpl.updateTopic(id,topic);
	}
	
	@RequestMapping(method = RequestMethod.DELETE,path ="/topic/{id}")
	public void removeTopic(@PathVariable int id) {
		 topicServiceImpl.removeTopicById(id);
	}
}
