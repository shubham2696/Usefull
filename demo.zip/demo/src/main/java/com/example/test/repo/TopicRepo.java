package com.example.test.repo;

import org.springframework.data.repository.CrudRepository;

import com.example.test.model.Topic;

public interface TopicRepo extends CrudRepository<Topic, Integer> {

}
