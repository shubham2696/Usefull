package com.example.test.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import com.example.test.model.Topic;

public interface TopicService {

	//To get all the topics
	public List<Topic> getAllTopics();
	
	//To get particular topic
	public Optional<Topic> getTopicById(int id);
	
	//To add topic
	public void addTopic(Topic topic);
	
	//To remove particular topic
	public void removeTopicById(int id);
		
	//To Update particular topic
	public void updateTopic(int id, Topic topic);
	
	
}
