package com.example.test.serviceImpl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.test.model.Topic;
import com.example.test.repo.TopicRepo;
import com.example.test.service.TopicService;

@Service
public class TopicServiceImpl implements TopicService {

	@Autowired
	private TopicRepo topicRepo;
	
	private List<Topic> topics =new ArrayList<>( Arrays.asList(
			new Topic(1, "Shubham", "sv@gmail.com"),
			new Topic(2, "Shubh", "shubh@gmail.com"),
			new Topic(3, "Shiv", "shiv@gmail.com")
			));
	
	@Override
	public List<Topic> getAllTopics() {
		List<Topic> list =(List<Topic>) topicRepo.findAll(); 
		return list;
	}

	@Override
	public Optional<Topic> getTopicById(int id) {
		return topicRepo.findById(id);
		 
		
	}

	@Override
	public void addTopic(Topic topic) {
		topicRepo.save(topic);
	}

	@Override
	public void removeTopicById(int id) {
		
		topicRepo.deleteById(id);
		//topics.removeIf(t -> t.getId()==id);
	}

	@Override
	public void updateTopic(int id, Topic topic) {
		
		topicRepo.save(topic);
		
		
	}
}
